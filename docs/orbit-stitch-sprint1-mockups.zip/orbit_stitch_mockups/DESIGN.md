---
name: Orbit
colors:
  background: '#ffffff'
  on-background: '#14123b'
  surface: '#ffffff'
  on-surface: '#14123b'
  surface-variant: '#f3f2ff'
  on-surface-variant: '#5b5a7a'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f2ff'
  surface-container: '#f3f2ff'
  surface-container-high: '#f3f2ff'
  surface-container-highest: '#f3f2ff'
  inverse-surface: '#14123b'
  inverse-on-surface: '#ffffff'
  outline: '#dad8f5'
  outline-variant: '#dad8f5'
  primary: '#6860f7'
  on-primary: '#ffffff'
  primary-container: '#e2e0ff'
  on-primary-container: '#14123b'
  inverse-primary: '#857eff'
  secondary: '#2ec4b6'
  on-secondary: '#14123b'
  secondary-container: '#d5f3f0'
  on-secondary-container: '#14123b'
  tertiary: '#ff7a59'
  on-tertiary: '#14123b'
  tertiary-container: '#ffe4de'
  on-tertiary-container: '#14123b'
  # Material 3 baseline error roles, pinned here for Stitch mockup rendering only.
  # Production code does not redefine them; it uses the Material 3 defaults from the theme.
  error: '#b3261e'
  on-error: '#ffffff'
  error-container: '#f9dedc'
  on-error-container: '#410e0b'
typography:
  headline-lg:
    fontFamily: Roboto
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 40px
  headline-md:
    fontFamily: Roboto
    fontSize: 28px
    fontWeight: '400'
    lineHeight: 36px
  headline-sm:
    fontFamily: Roboto
    fontSize: 24px
    fontWeight: '400'
    lineHeight: 32px
  title-lg:
    fontFamily: Roboto
    fontSize: 22px
    fontWeight: '400'
    lineHeight: 28px
  title-md:
    fontFamily: Roboto
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  title-sm:
    fontFamily: Roboto
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  body-lg:
    fontFamily: Roboto
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Roboto
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Roboto
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Roboto
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-md:
    fontFamily: Roboto
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: Roboto
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.5rem
  md: 0.75rem
  DEFAULT: 1rem
  lg: 1.5rem
  xl: 2rem
  full: 9999px
spacing:
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  margin: 1rem
  gutter: 1rem
---

## Brand & Style

Orbit is a shared organizer for housemates, families and small groups: tasks, chores, bills, lists and events. The feel is calm, cooperative and modern.

Use Material 3 components in a mobile portrait layout shared by Android and iOS. Reference viewport: 360x800.

Use flat solid colors and tonal layering only. No gradients, drop shadows, glow, blur, photos or illustrations of people. Do not introduce translucent fills or arbitrary opacity. The only opacity exception is the dark-scheme outline explicitly defined as raw violet `#6c63ff` at 50%, matching the code.

The type is the default Material 3 scale in Roboto until a brand font is chosen in code.

### Material 3 and Orbit theme boundary

- Use stable Material 3 components and patterns as the structural baseline.
- Style components through Orbit theme roles only: color scheme, typography, shapes and Orbit semantic colors.
- Do not use dynamic/wallpaper color.
- Do not invent component-specific colors outside the Orbit palette.
- Do not use experimental Material 3 Expressive-only patterns or APIs as a requirement for these mockups.
- The mockups are visual references only. Production screens are implemented with `OrbitTheme` and design-system wrappers, never from Stitch-exported code.
- Error states use the Material 3 error roles. The error hex values in this document are pinned for Stitch mockups only; production uses the Material 3 error roles supplied by the theme. Coral is never an error color.

## Colors

Use EXACTLY the hex values listed here. Do not generate darker, lighter, muted, blended or derived tones. Do not replace these values with colors generated from seed colors.

Every screen must have both a light and a dark variant.

### Light scheme

- **Primary `#6860f7`** with white `#ffffff` text on filled primary controls.
- **Canvas/background `#ffffff`** with primary text `#14123b`.
- **Secondary text `#5b5a7a`.**
- **Cards, inputs and other tonal surfaces `#f3f2ff`.**
- **Borders and outlines `#dad8f5`.**
- **Primary container `#e2e0ff`** with navy `#14123b` text.
- Primary-colored text `#6860f7` is allowed only on white `#ffffff`.
- On `#f3f2ff` and `#e2e0ff`, use navy `#14123b` for text. Primary may be used for icons where needed.
- Never use raw brand violet `#6c63ff` for text or buttons.

### Dark scheme

- **Primary `#857eff`** with navy `#14123b` text on filled primary controls.
- **Background and surface `#14123b`** with white `#ffffff` primary text.
- **Secondary text `#c9c6ff`.**
- **Cards and tonal/elevated surfaces `#221e5c`.**
- **Deepest layer `#0b0a24`**, used for the bottom navigation background and other explicitly deepest surfaces.
- **Primary container `#332e80`** with white `#ffffff` text.
- **Outline:** raw violet `#6c63ff` at 50% opacity, exactly as defined in code.
- **Divider / outline variant:** `#221e5c`.
- **Material 3 error roles for mockup rendering:** error `#f2b8b5`, on-error `#601410`, error-container `#8c1d18`, on-error-container `#f9dedc`.
- Primary `#857eff` may be used for text or icons on `#14123b` and `#221e5c`.

### Teal, coral and sun: solid fills only

- **Teal `#2ec4b6`**: success, done, settled.
- **Sun `#ffc857`**: warning, pending, due soon.
- **Coral `#ff7a59`**: create actions such as the extended FAB "New item", urgent badges and other approved callouts.
- Text and icons on teal, sun and coral fills are always navy `#14123b`, never white.
- Teal, sun and coral are never used as text or icon colors on a light background.
- Do not apply opacity to teal, sun or coral fills.
- Light containers: teal `#d5f3f0`, coral `#ffe4de`, both with navy `#14123b` text.
- Dark containers: teal `#1d5066`, coral `#663646`, both with white `#ffffff` text.
- Errors use the Material 3 error roles listed in this document for mockup rendering. Production uses the theme-provided Material 3 roles. Coral is never an error color.

### Space identity accents

The only space identity accent colors are:

- `#6c63ff`
- `#ff7a59`
- `#2ec4b6`
- `#ffc857`

They are decorative only: avatar borders, dots and similar identity marks. Never place body text on an accent fill and never use these raw accents as ordinary text colors.

### Contrast

Every text/background pair must reach at least WCAG AA 4.5:1 for normal text.

Important light-scheme examples:
- `#6860f7` on `#ffffff`: allowed.
- `#6860f7` on `#f3f2ff`: not allowed for normal text.
- `#6860f7` on `#e2e0ff`: not allowed for normal text.

Interactive boundaries and essential icons must remain visually distinguishable. All tappable controls must have a touch target of at least 48x48dp even when the visible icon, checkbox or chip is smaller.

## Typography

Use the default Material 3 type scale in Roboto. Use sentence case for labels and buttons. No custom font.

## Layout & Spacing

Mobile first, 360x800 reference.

Use only these spacing values:
- 4
- 8
- 16
- 24
- 32

The spacing scale applies to margins, gaps and padding. Fixed component dimensions may use values outside the spacing scale when required by Material 3 or by an explicit Orbit mockup decision.

Rules:
- Screen margins: 16.
- Gaps between cards: 8 or 16.
- Card padding: 16.
- Section spacing: 24 or 32.
- Margins, gaps and padding must not introduce 10, 12, 20, 28, 40 or other off-scale spacing values.
- Every tappable element has a minimum 48x48dp touch target.
- A visible element may be smaller than 48dp only if its interactive hit area still reaches 48x48dp.

## Elevation & Depth

Use tonal layering only.

Light:
- canvas `#ffffff`
- cards / tonal surfaces `#f3f2ff`

Dark:
- canvas `#14123b`
- cards / tonal surfaces `#221e5c`
- deepest layer `#0b0a24`

No drop shadows, glow, gradients or blur.

## Shapes

Use only these radii:
- 8
- 12
- 16
- 24
- 32

Component rules:
- Cards: 16.
- Inputs: 16.
- Compact chips: 8 unless the Material 3 component is explicitly pill-shaped.
- Bottom sheets: 24 on top corners.
- Buttons, extended FABs and avatars: fully rounded according to the Material 3 component.
- Checkbox visible shape: 8.
- Never use 10, 20, 80 or arbitrary radii.

## Components

### Filled button

- Minimum height / touch target: 48dp.
- Light: fill `#6860f7`, text/icon `#ffffff`.
- Dark: fill `#857eff`, text/icon `#14123b`.
- Use Material 3 label typography.
- Pill-shaped according to the Material 3 button shape.

### Extended FAB

- Label: **"New item"**.
- Fill: coral `#ff7a59` in both schemes.
- Text and icon: navy `#14123b`.
- No shadow.
- Standard Material 3 extended FAB height: 56dp.
- Minimum touch dimension: 48dp.
- Fully rounded / Material 3 extended-FAB shape.

### Outlined and text actions

Light:
- Text action on white: primary `#6860f7`.
- On `#f3f2ff` or `#e2e0ff`, use navy `#14123b` text instead of primary.
- Outline: `#dad8f5`.

Dark:
- Text/icon action: primary `#857eff` on `#14123b` or `#221e5c`.
- Outline: `#6c63ff` at 50% opacity.

Do not introduce derived hover/pressed colors into the static mockups.

### Filter chips

Light:
- Unselected: fill `#f3f2ff`, text `#5b5a7a`.
- Selected: fill `#6860f7`, text `#ffffff`.

Dark:
- Unselected: fill `#221e5c`, text `#c9c6ff`.
- Selected: fill `#857eff`, text `#14123b`.

Interactive chip hit areas must reach at least 48dp even if the visible chip is more compact.

### Status chips

Use solid fills only:
- Done / success: teal `#2ec4b6`.
- Due soon / warning: sun `#ffc857`.
- Urgent: coral `#ff7a59`.

Text and icons are always navy `#14123b`.

No tinted-opacity variants and no derived semantic colors.

### Cards

Light:
- Fill `#f3f2ff`.

Dark:
- Fill `#221e5c`.

Both:
- Radius 16.
- Padding 16.
- No border unless a specific state requires one.
- No shadow.
- Use scheme-appropriate text colors.

### Inputs

Light:
- Fill `#f3f2ff`.
- Main text `#14123b`.
- Supporting / placeholder text `#5b5a7a`.
- Focus stroke `#6860f7`.

Dark:
- Fill `#221e5c`.
- Main text `#ffffff`.
- Supporting / placeholder text `#c9c6ff`.
- Focus stroke `#857eff`.

Both:
- Radius 16.
- Minimum height 56dp (Material 3 TextField / OutlinedTextField default).
- Touch target at least 48dp.
- Focus stroke: 2px.
- Error state: standard Material 3 error roles from the theme, never coral.
- No glow or shadow.

### Checkbox for task completion

Visible checkbox:
- 24x24dp.
- Radius 8.
- Stroke width 2px when unchecked.

Light unchecked:
- Stroke `#5b5a7a`.

Dark unchecked:
- Stroke `#c9c6ff`.

Checked in both schemes:
- Fill teal `#2ec4b6`.
- Checkmark navy `#14123b`.

The visible checkbox remains 24x24dp, but the tappable hit area must be at least 48x48dp.

### Navigation

Use a Material 3 bottom navigation bar with exactly:
- Home
- Calendar
- Expenses
- Assistant
- Settings

Light:
- Bar background `#ffffff`.
- Active indicator `#e2e0ff`.
- Active label `#14123b`.
- Active icon may use `#6860f7`.
- Inactive content `#5b5a7a`.

Dark:
- Bar background `#0b0a24`.
- Active indicator `#332e80`.
- Active label `#ffffff`.
- Active icon may use `#857eff`.
- Inactive content `#c9c6ff`.

Each navigation destination has at least a 48x48dp touch target.

### Member avatars

- Circular visible avatar: 36x36dp (Orbit mockup choice; this is a component dimension, not spacing).
- Overlapping cluster.
- Trailing `+N` chip when more members exist.
- Avatar interaction, if tappable, must use a hit target of at least 48x48dp.

Light:
- Avatar fill `#e2e0ff`.
- Initials `#14123b`.
- 2px border using one space identity accent: `#6c63ff`, `#ff7a59`, `#2ec4b6` or `#ffc857`.

Dark:
- Avatar fill `#332e80`.
- Initials `#ffffff`.
- 2px border using one of the same space identity accents.

Do not fill the avatar itself with the accent color.

## Stitch generation rules

These rules apply to every generated screen:

- Text and icons on teal `#2ec4b6`, sun `#ffc857` and coral `#ff7a59` are navy `#14123b`.
- Avatar initials use navy `#14123b` on `#e2e0ff` in light mode and white `#ffffff` on `#332e80` in dark mode; accents are borders only.
- Light primary text `#6860f7` is used only on white `#ffffff`.
- Light cards and tonal surfaces are exactly `#f3f2ff`; dark cards and tonal surfaces are exactly `#221e5c`.
- Dark bottom navigation / deepest layer is exactly `#0b0a24`.
- Use stable Material 3 components as the structural baseline.
- Style them only with the Orbit theme roles and tokens defined in this document.
- Do not use dynamic/wallpaper color.
- Do not rely on experimental Material 3 Expressive-only components or visual patterns.
- Use EXACTLY the colors specified for the relevant light or dark scheme.
- Do not derive new tonal colors from primary, secondary, tertiary or neutral seeds.
- Do not replace `#6860f7` with raw violet `#6c63ff` in light primary roles.
- Do not replace coral `#ff7a59` with darker rust/orange tones.
- Do not use navy variants such as `#18163f`; use exactly `#14123b`.
- Do not use white text on teal, sun or coral.
- Do not use teal, sun or coral as text/icon colors on light backgrounds.
- Do not use primary-colored light text on `#f3f2ff` or `#e2e0ff`.
- Do not use accent-color fills behind avatar initials.
- Do not duplicate headers or navigation elements.
- Do not generate elements with tap targets smaller than 48x48dp.
- Do not generate shadows, gradients, blur, glow or translucent fills.
- The only permitted opacity is the dark outline `#6c63ff` at 50%.
- Do not introduce off-scale spacing or radii.
- Keep light and dark variants structurally identical unless content requires otherwise.
